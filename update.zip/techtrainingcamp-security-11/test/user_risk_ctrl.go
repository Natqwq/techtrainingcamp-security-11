package main

import "github.com/gin-gonic/gin"

func slide_bar(c *gin.Context){

}//滑动条

func wait(c *gin.Context){

}//等待一段时间重试

func ban(c *gin.Context){

}//禁止用户后续操作